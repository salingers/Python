py-snippets
===========

A collection of various kinds of Python bits and pieces. No big tools,
just experiments. At the moment the main thing is a set of demos of
various machine learning algorithms.