tex2epub
--------

A simple Python script for converting LaTeX books to EPub format. The
resulting EPub works with Amazon tools, and can thus easily be
converted to Kindle ebooks.

The script is mostly general, with some hacks that are specific to my
book. It only supports exactly what I needed for the book.

In short, this may save you some time if you need your own converter
where you can control the output, but it's not a general converter.