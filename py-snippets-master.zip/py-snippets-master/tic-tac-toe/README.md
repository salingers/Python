tic-tac-toe
===========

A stupid simple tic-tac-toe game where one of the computer players can
learn to play better by experience. Uses Swing, so it requires Jython
to run.