python earthquakes.py
python poisson.py vedur.csv
python find-anomalies.py vedur.csv
