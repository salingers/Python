
A script for predicting the ratings of beers based on past ratings,
using linear regression.  There's also a script doing principal
component analysis of the data set.

To try it out, simply run:

    python predict-rating.py

To try the PCA, run:

    python pca.py
